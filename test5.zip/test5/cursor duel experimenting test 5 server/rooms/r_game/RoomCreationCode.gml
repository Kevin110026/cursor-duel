global.playerChars = [];
show_debug_message(global.playerScore);
if(is_undefined(global.playerScore))
	global.playerScore = [0, 0];


clients = obj_server.socket_list;

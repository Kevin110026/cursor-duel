//
// Simple passthrough fragment shader
//
varying vec2 v_vTexcoord;
varying vec4 v_vColour;

uniform float gray_start; // 0.0 ~ 1.0
uniform bool grayer; // 0.0 ~ 1.0


void main()
{
    gl_FragColor = v_vColour * texture2D( gm_BaseTexture, v_vTexcoord );
	
	//if(v_vTexcoord.y > 0.5)
	//{
	//	gl_FragColor[0] *= 0.0;
	//	gl_FragColor[1] *= 0.0;
	//	gl_FragColor[2] *= 0.0;
	//}
	
	if (grayer)
	{
		gl_FragColor[0] *= 0.5;
		gl_FragColor[1] *= 0.5;
		gl_FragColor[2] *= 0.5;
	}
	//	idfk why it's bugged - the y value is between 0.0 to 0.5 instead of 0.0 to 1.0
	if (1.0 - v_vTexcoord.y * 2.0 < gray_start)
	{
		gl_FragColor[0] *= 0.75;
		gl_FragColor[1] *= 0.75;
		gl_FragColor[2] *= 0.75;
	}
}
